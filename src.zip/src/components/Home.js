import { useState, useEffect } from "react";

function Home() {
  const [api, setAPI] = useState("");
  const [list, setList] = useState([]);

  const url = "http://localhost:5000/pizzas";

  // отримання API ключа з localStorage
  useEffect(() => {
    const savedKey = localStorage.getItem("apiKey");
    if (savedKey) {
      setAPI(JSON.parse(savedKey));
    }
  }, []);

  // лог для перевірки
  useEffect(() => {
    console.log(list);
  }, [list]);

  // запит до API
  const getByFetchAPI = () => {
    fetch(url, {
      headers: {Authorization: api ? `Bearer ${api}` : ""}
    })
      .then(response => response.json())
      .then(data => {setList(data);})
      .catch(error => console.log(error));
  };

  return (
    <div>
      <h1>Welcome</h1>

      <button onClick={getByFetchAPI}>Завантажити піци</button>

      {list.map((pizza, index) => (
        <div key={pizza.id || index}>
          <h3>{pizza.name}</h3>
          <p>{pizza.price} грн</p>
        </div>
      ))}
    </div>
  );
}

export default Home;