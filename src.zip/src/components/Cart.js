import { useEffect, useState } from "react";

function Cart() {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(savedCart);
  }, []);
  const order = async () => {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];

    const response = await fetch("http://localhost:5000/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        items: cart,
        total: cart.reduce((sum, item) => sum + item.price, 0)
      })
    });

    const data = await response.json();
    console.log(data);

    localStorage.removeItem("cart");
  };

  return (

    <div>
      <h1>Cart</h1>

      {cart.map((pizza, index) => (
        <div key={index}>
          <h3>{pizza.name}</h3>
          <p>{pizza.price} грн</p>
        </div>
      ))}
      <button onClick={order}>Order</button>
    </div>
  );
}

export default Cart;