import logo from './logo.svg';
import './App.css';
import AppRouter from './components/AppRouter';

function App() {
  return (
    <div className="App">
      <nav className='nav bg-warning'>
        <a className='nav-link' aria-current='page' href='http://localhost:3000/home'>Home</a>
        <a className='nav-link' aria-current='page' href='http://localhost:3000/cart'>Cart</a>
        <a className='nav-link' aria-current='page' href='http://localhost:3000/auth'>Login</a>
      </nav>
      <AppRouter/>
    </div>
  );
}

export default App;
